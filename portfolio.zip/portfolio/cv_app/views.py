from django.shortcuts import render, redirect, get_object_or_404
from .models import Profile, Education, Experience, Skill # أضفنا Skill
from .forms import ProfileForm, EducationForm, ExperienceForm, SkillForm # أضفنا SkillForm


# دالة الصفحة الرئيسية (الواجهة الترحيبية للموقع)
def landing_page(request):
    return render(request, 'landing_page.html')
# دالة عرض السيرة الذاتية (الصفحة النهائية)
def home(request):
    profile = Profile.objects.last()
    return render(request, 'home.html', {'profile': profile})

# الخطوة 1: البيانات الأساسية
def cv_builder(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST)
        if form.is_valid():
            profile = form.save()
            return redirect('add_education', profile_id=profile.id) 
    else:
        form = ProfileForm()
    return render(request, 'cv_builder.html', {'form': form})

# الخطوة 2: إضافة التعليم
def add_education(request, profile_id):
    profile = get_object_or_404(Profile, id=profile_id)
    if request.method == 'POST':
        form = EducationForm(request.POST)
        if form.is_valid():
            education = form.save(commit=False)
            education.profile = profile
            education.save()
            return redirect('add_experience', profile_id=profile.id) 
    else:
        form = EducationForm()
    return render(request, 'add_education.html', {'form': form, 'profile': profile})

# الخطوة 3: إضافة الخبرات والمشاريع
def add_experience(request, profile_id):
    profile = get_object_or_404(Profile, id=profile_id)
    if request.method == 'POST':
        form = ExperienceForm(request.POST)
        if form.is_valid():
            experience = form.save(commit=False)
            experience.profile = profile
            experience.save()
            # غيرنا التوجيه هنا ليذهب للخطوة الرابعة (المهارات)
            return redirect('add_skill', profile_id=profile.id) 
    else:
        form = ExperienceForm()
    return render(request, 'add_experience.html', {'form': form, 'profile': profile})

# الخطوة 4: إضافة المهارات (الدالة الجديدة والأخيرة)
# الخطوة 4: إضافة المهارات (المتعددة)
def add_skill(request, profile_id):
    profile = get_object_or_404(Profile, id=profile_id)
    
    if request.method == 'POST':
        # نسحب كل المدخلات اللي أسمها skills[] من الفورمة كقائمة
        skills_list = request.POST.getlist('skills[]') 
        
        for skill_name in skills_list:
            if skill_name.strip(): # نتأكد أن المربع مو فارغ قبل الحفظ
                Skill.objects.create(profile=profile, skill_name=skill_name.strip())
                
        return redirect('home') 
        
    return render(request, 'add_skill.html', {'profile': profile})


# دالة لوحة التحكم (Dashboard)
def dashboard(request):
    # مؤقتاً نجلب آخر حساب تم إنشاؤه (لحين برمجة نظام تسجيل الدخول لاحقاً)
    profile = Profile.objects.last()
    return render(request, 'dashboard.html', {'profile': profile})

# دالة تعديل البيانات الأساسية
def edit_profile(request, profile_id):
    profile = get_object_or_404(Profile, id=profile_id)
    
    if request.method == 'POST':
        # السطر السحري (instance=profile) يخبر جانغو أننا نعدل بيانات موجودة ولا ننشئ جديدة
        form = ProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
           # داخل دالة add_skill، بعد الـ save
        return redirect('dashboard') # توجيه الزبون للوحة التحكم بعد اكتمال الإدخال# بعد التعديل نرجعه للوحة التحكم
    else:
        # عرض الفورمة ممتلئة بالبيانات القديمة
        form = ProfileForm(instance=profile)
        
    # نستخدم نفس صفحة الإدخال السابقة، لكن البيانات ستكون موجودة بداخلها
    return render(request, 'cv_builder.html', {'form': form})
# --- دوال الحذف ---

def delete_education(request, edu_id):
    education = get_object_or_404(Education, id=edu_id)
    education.delete()
    return redirect('dashboard')

def delete_experience(request, exp_id):
    experience = get_object_or_404(Experience, id=exp_id)
    experience.delete()
    return redirect('dashboard')

def delete_skill(request, skill_id):
    skill = get_object_or_404(Skill, id=skill_id)
    skill.delete()
    return redirect('dashboard')