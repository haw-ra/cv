from django.db import models

# جدول البيانات الأساسية (تم إنشاؤه مسبقاً)
class Profile(models.Model):
    name = models.CharField(max_length=100)
    job_title = models.CharField(max_length=100)
    email = models.EmailField()
    bio = models.TextField()
    social_link = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.name

# 1. جدول التعليم
class Education(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE) # ربط التعليم بالملف الشخصي
    university = models.CharField(max_length=150) # اسم الجامعة
    degree = models.CharField(max_length=100) # الشهادة (مثلاً: بكالوريوس علوم حاسوب)
    graduation_year = models.CharField(max_length=4) # سنة التخرج

    def __str__(self):
        return f"{self.degree} - {self.university}"

# 2. جدول الخبرات والمشاريع
class Experience(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    company_or_project = models.CharField(max_length=150) # اسم الشركة أو المشروع
    job_role = models.CharField(max_length=100) # المسمى الوظيفي
    description = models.TextField() # تفاصيل الإنجازات

    def __str__(self):
        return self.job_role

# 3. جدول المهارات
class Skill(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    skill_name = models.CharField(max_length=50) # اسم المهارة (مثلاً: Python, Django, OpenCV)

    def __str__(self):
        return self.skill_name