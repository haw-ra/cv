# pyright: reportMissingModuleSource=false
from django.contrib import admin
from .models import Profile, Education, Experience, Skill

# تسجيل الجداول حتى تظهر في لوحة التحكم
admin.site.register(Profile)
admin.site.register(Education)
admin.site.register(Experience)
admin.site.register(Skill)